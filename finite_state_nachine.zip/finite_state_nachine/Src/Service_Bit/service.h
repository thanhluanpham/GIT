/*
 * service.h
 *
 *  Created on: May 30, 2020
 *      Author: Luan_Pham
 */

#ifndef SERVICE_BIT_SERVICE_H_
#define SERVICE_BIT_SERVICE_H_

void Put_bit(uint16_t* const Data,uint8_t BitPn,uint8_t Value);
void LaunchPad_out(uint8_t output_data);
uint8_t LaunchPad_input(void);
//void Newfunct(uint32_t* const giatri);//testingonly
#endif /* SERVICE_BIT_SERVICE_H_ */
